#define USECHRONO
#undef HAVE_MPI

#include "eval.hpp"
#include <cassert>
#include <climits>
#include <cstdlib>
#include <stack>
using namespace aed;
using namespace std;

// bool even(int x) { return x%2==0; }
// bool odd(int x) { return x%2; }
// bool ge7(int x) { return x>=7; }
// bool le3(int x) { return x<=3; }
// bool div4(int x) { return x%4==0; }
// bool isprime(int x) { return is_prime(abs(x)); }
// bool isnotprime(int x) { return !is_prime(abs(x)); }

//---:---<*>---:---<*>- COMIENZA CODIGO FUNCION --:---<*>---:---<*>---:---<*>
// COMPLETAR DNI y NOMBRE AQUI:
// Nombre: Bob Esponja
int DNI=23456789;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
set<int> setinters(list<set<int>> &LS, set<int> &S,
                   bool (*pred)(int)) {
  return set<int>();
}                                                                    

int main() {
  Eval ev;
  int vrbs=0;
  ev.eval<1>(setinters,vrbs);
  return 0;
}
