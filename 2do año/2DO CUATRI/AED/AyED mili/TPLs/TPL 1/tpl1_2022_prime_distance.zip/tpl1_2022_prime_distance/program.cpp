#define USECHRONO
#undef HAVE_MPI

typedef int (*mapfun_t)(int);

int f1(int a) { return a%2; }
int f2(int a) { return a; }
int f3(int a) { return 2*a; }
int f4(int a) { return a*a; }

#include "eval.hpp"
#include <cassert>
#include <climits>
#include <cstdlib>
#include <stack>
using namespace aed;
using namespace std;

// COMPLETAR DNI y NOMBRE AQUI:
// Nombre: Bob Esponja
int DNI=23456789;

void prime_distance(list<int> &L){

 //resuelva aqui el ejercicio
  
}


//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
  Eval ev;
  int vrbs=0;
  ev.eval<1>(prime_distance,vrbs);
  return 0;
}
