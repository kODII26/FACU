#include <climits>
#include <cstdlib>
#include <iostream>
#include <stack>
#include "./btree.h"
#include "./btreetools.h"

/* COMIENZO DE DESCRIPCION

   [Tomado en el Trabajo Practico de Laboratorio Nro 2
   (TPL1R) de 2015-10-03].  
   keywords: lista

FIN DE DESCRIPCION */

using namespace aed;
using namespace std;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
// Version con puntero a funcion
#undef apply
#define apply apply2
typedef int(*map_fun_t)(int);

template<class T> 
void apply(btree<T> &Q,
           typename btree<T>::iterator n,
           map_fun_t f) {
  if (n==Q.end()) return;
  *n = f(*n);
  apply(Q,n.left(),f);
  apply(Q,n.right(),f);
}
template<class T>
void apply(btree<T> &Q,map_fun_t f) {
  apply(Q,Q.begin(),f); 
}

int sum(int x) { return x+100; }

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
// Version con template
#undef apply
#define apply apply3

template<class T,class F>
void apply(btree<T> &Q,
           typename btree<T>::iterator n,
           F &f) {
  if (n==Q.end()) return;
  *n = f(*n);    
  apply(Q,n.left(),f);
  apply(Q,n.right(),f);
}

#define STR(a) #a

template<class T,class F>
void apply(btree<T> &Q,F &f) {
  apply(Q,Q.begin(),f);
}

// Ejemplo: sumar un valor "w" a todos los nodos
// del arbol
class sumw_t {
public:
  int w;
  int operator()(int x) { return x+w; }
} sumw;


//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
// Version con polimorfismo
#undef apply
#define apply apply4


class map_t {
public:
  virtual int operator()(int x)=0;
};

template<class T>
void apply(btree<T> &Q,
           typename btree<T>::iterator n,
           map_t &f) {
  if (n==Q.end()) return;
  *n = f(*n);    
  apply(Q,n.left(),f);
  apply(Q,n.right(),f);
}

template<class T>
void apply(btree<T> &Q,map_t &f) {
  apply(Q,Q.begin(),f);
}

// Ejemplo: poner todos los
// valores nodales >z a z (cutoff), es decir
// *n = min(*n,z)
class cutoff_t : public map_t {
public:
  int z;
  int operator()(int x) { return (x>z? z : x); }
};


//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {

#undef apply
#define apply apply2
  btree<int> T,T2;
  make_random_btree(T,10,1.2);
  T.lisp_print();
  cout << endl;
  T2=T;

  apply(T,sum);
  T.lisp_print();
  cout << endl;

#undef apply
#define apply apply3
  //...
  sumw.w = 1000; 
  apply(T,sumw);
  T.lisp_print();
  cout << endl;


#undef apply
#define apply apply4
  //...
  cout << "T: " << endl;
  T2.lisp_print();
  cout << endl;

  cutoff_t cutoff;   
  cutoff.z = 5;
  apply(T2,cutoff);
  cout << "cutoff a 5: " << endl;
  T2.lisp_print();
  cout << endl;

  
  return 0;
}
