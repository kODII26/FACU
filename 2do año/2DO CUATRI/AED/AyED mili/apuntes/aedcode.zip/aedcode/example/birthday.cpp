#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <set>
using namespace std;

// Check BIRTHDAY effect
int main() {
  // int m=23,N=365,ntries=100000;
  int m=1000,N=m*m,ntries=1000;
  int ncolcum=0,ntriecum=0;
  // El valor exacto se obtiene diciendo que en total
  // la cantidad de eventos distintos en los cuales se
  // pueden elegir m objetos diferentes es N*(N-1)*(N-2)...(N-m+1)
  // y la cantidad de posibles elecciones (donde pueden ser
  // iguales o distintos) es N^m. Entonces la probabilidad
  // de que NO haya colision es
  // P = \Pi_j=0^{m-1} (N-j)/N^m,
  // P = \Pi_j=0^{m-1} {1-j/N},
  // -log P \approx \Sum_j=0^{m-1} j/N = m(m-1)/2*N
  // o sea P = exp(-m*(m-1)/(2*N)
  double Prob = 1.0-exp(-double((m-1)*m)/(2*N));
  while (1) {
    int collisions=0;
    for (int j=0; j<ntries; j++) {
      set<int> S;
      for (int j=0; j<m; j++) {
        int x = rand()%N;
        if (S.find(x)!=S.end()) {
          collisions++;
          break;
        }
        S.insert(x);
      }
    }
    ncolcum += collisions;
    ntriecum += ntries;
    printf("tries %d, collisions %d, prob collision chunk=%f, cum %f (aprox %f)\n",
           ntries,collisions,double(collisions)/ntries,double(ncolcum)/ntriecum,Prob);
  }
  return 0;
}
