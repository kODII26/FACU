// $Id$

/* 
   COMIENZO DE DESCRIPCION 

   Dados los conjuntos S1=(1,3,5,7), S2=(1,3,5,9),
   S3=(11,23,6,7), S4=(10,3,6,9), decimos que D=(6,9) es un
   conjunto DISCRIMINADOR ya que cada uno de los conjuntos
   se puede identificar en forma unica por si contiene a los
   elementos de D, por ejemplo: S1 es el unico que no
   contiene ni a 6 ni a 9, S2 contiene a 9 pero no a 6, S3
   contiene a 6 y no a 9, y S4 los contiene a los dos.  Se
   puede ver que siempre se puede encontrar un tal conjunto
   de discriminadores (por ejemplo la union de todos los
   conjuntos), a condicion por supuesto que todos los
   conjuntos sean distintos.  
   
   Consigna 1: Escribir una funcion 
   #void choose_discr(vector< set<int> > &sets,# 
   #set<int> &discrtrs);# que elige un conjunto de discriminadores
   #discrtrs#, tratando que sea de tamano minimo. 

   Consigna 2: Escribir una funcion 
   #int verif_discrim(vector< set<int> > &sets,# 
   #set<int> &discrtrs);# que determina si el conjunto #discrtrs# es
   efectivamente un conjunto de discriminadores para #sets#.

   __USE_WIKI__
   [Tomado en tercer parcial 2010-11-24].
   keywords: conjunto, correspondencia 
    
   FIN DE DESCRIPCION */

// -----------------------------------------------------------------
#include <cassert>
#include <cstdio>
#include <cmath>
#include <vector>
#include <set>
#include "./util.h"
using namespace std ;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void printset(const set<int> &s,const char *label=NULL) {
  if (label) printf("%s: ",label);
  set<int>::iterator q = s.begin();
  while (q!=s.end()) printf("%d ",*q++);
  printf("\n");
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
// Elige un discrminador `d' con el siguiente algoritmo.
// Construye la correspondencia `freq' que determina para
// cada elemento de los conjuntos en cuantos conjuntos
// aparece.  De ahi escoge el elemento que esta en un numero
// de conjuntos lo mas parecido posible a nset/2. Notar que
// si lograramos que siempre fuera nset/2 entonces podriamos
// construir un conjunto discrimador de longitud minima
// log2(nset).  El valor de retorno indica si se pudo
// encontrar un discrimador, si no se pudo encontrar quiere
// decir que todos los elementos son iguales,
int choose1_discr(vector< set<int> > &sets,int &d) {
  // Construye la tabla de frecuencias
  map<int,int> freq;
  int nset=sets.size();
  for (int j=0; j<nset; j++) {
    set<int> &s = sets[j];
    set<int>::iterator q = s.begin();
    while (q!=s.end()) freq[*q++]++;
  }
  // Buscamos aquel elemento que esta en un numero
  // de conjuntos lo mas parecido posible a nset/2
  int nset2 = nset/2;
  map<int,int>::iterator r = freq.begin(),rmin = freq.end();
  int difmin = nset;
  while (r!=freq.end()) {
    int dif = abs(r->second-nset2);
    if (rmin==freq.end() || dif<difmin) {
      rmin = r;
      difmin = dif;
    }
    r++;
  }
  d = rmin->first;
  // El discrminador esta OK si al menos NO esta
  // en un conjunto
  return rmin->second < nset;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
// Elige un conjunto de discrimadores `discrtrs' para
// `sets'.  Primero elige un solo discrimador `d', separa
// los conjuntos en `d1' (los que contienen a `d') y `d0'
// (los que NO contienen a `d').  Despues aplica
// recursivamente a `d0' y `d1'. La recursion se detiene
// cuando el numero de conjuntos es <2 o no es posible
// encontrar un discriminador porque todos los conjuntos son
// iguales.
void choose_discr(vector< set<int> > &sets,
                  set<int> &discrtrs) {
  int nset = sets.size();
  if (nset<2) return;
  // Encuentra un discriminador
  int d;
  int ok = choose1_discr(sets,d);
  // Si no es posible termino (son todos iguales)
  if (!ok) return;
  // Inserta el discrminador en `discrtrs'
  discrtrs.insert(d);
  // Separa `sets' en aquellos que contienen a `d' (`d0') y
  // los que NO contienen a `d' (`d1'). 
  vector< set<int> > d0, d1;
  for (int j=0; j<nset; j++) {
    set<int> &s = sets[j];
    if (s.find(d)!=s.end()) {
      d1.push_back(s);
    } else {
      d0.push_back(s);
    }
  }
  // Verifica que el discriminador sea efectivo, es decir
  // al menos un conjunto lo debe contener y otro no. 
  assert(d0.size()<nset);
  assert(d1.size()<nset);
  // Aplica recursivamente a `d0' y `d1'
  choose_discr(d0,discrtrs);
  choose_discr(d1,discrtrs);
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>

// Retorna 1 si efectivamente `discrtrs' es un conjunto de
// discriminadores para `sets', si no retorna 0. Para ello
// toma un discriminador `d' de `discrtrs' y separa en los
// que contienen a `d' y los que no lo contienen. Despues
// aplica recursivamente para `d0' y `d1' habiendo eliminado
// `d' de la lista de discriminadores. La recursion se
// detiene cuando el numero de conjuntos es <=1 (no hace
// falta discriminar) o si el numero de conjuntos es >=1 y
// no hay mas discriminadores (retorna 0, porque no esta
// pudiendo discrminar). 
int verif_discrim(vector< set<int> > &sets,
                  set<int> &discrtrs) {
  int nset = sets.size();
  if (nset<=1) return 1;
  if (!discrtrs.size()) return 0;
  // Extrae un discriminador `d' y construye un nuevo
  // conjunto de discriminadores `newdisc' con ese
  // eliminado.
  set<int> newdisc = discrtrs;
  int d = *newdisc.begin();
  newdisc.erase(newdisc.begin());
  // separa en los que contienen a `d' y los que no lo contienen. 
  vector< set<int> > d0,d1;
  for (int j=0; j<nset; j++) {
    set<int> &s = sets[j];
    if (s.find(d)!=s.end()) {
      d1.push_back(s);
    } else {
      d0.push_back(s);
    }
  }
  // Aplica recursivamente a `d0' y `d1'
  return verif_discrim(d0,newdisc) 
    && verif_discrim(d1,newdisc);
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
// Hace un test aleatorio
void test1() {
  // nu := los elementos de los conjuntos son aleatorios en [0,nu)
  // setsize := el tamano de cada conjunto
  // nset := la cantidad de conjuntos
  int nu=200, setsize=nu/2, nset=nu/2;
  // Popula el vector de conjuntos con elementos aleatorios. 
  vector< set<int> > sets(nset);
  for (int j=0; j<nset; j++) {
    set<int> &s = sets[j];
    for (int k=0; k<setsize; k++)
      s.insert(rand()%nu);
  }

#if 0
  for (int j=0; j<nset; j++) {
    printf("sets[%d]",j);
    printset(sets[j]);
  }
#endif

  // Llama a la funcion para determinar los discriminadores
  set<int> discrtrs;
  choose_discr(sets,discrtrs);

  // printset(discrtrs,"discrtrs");
  // Imprime el numero de discriminadores y compara con el
  // numero optimo. 
  printf("nbr of discriminators %d, optimal %d\n",
         discrtrs.size(),int(ceil(log2(sets.size()))));
  // printf("verif discriminators: %d\n",
  //        verif_discrim(sets,discrtrs));

  // Verifica si se pueden cuantos elementos de `discrtrs'
  // se pueden eliminar aunque sigan siendo discriminadores.
  int ok = 1;
  while (ok) {
    discrtrs.erase(discrtrs.begin());
    // printset(discrtrs,"new discriminators: ");
    ok = verif_discrim(sets,discrtrs);
  }
  printf("failed with %d discriminators\n",discrtrs.size());
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
  for (int j=0; j<100; j++) test1();
  return 0;
}
