#include <cstdio>
#include <cassert>
#include <cmath>

#include <list>
#include <algorithm>

#include "./util.h"

using namespace std;

// EJERCICIO PARA LISTA ORDITERS: Dado una lista list<int> L y una lista
// de POSICIONES (iteradores) en esa lista list<list::iterator> it_list,
// determinar si las posiciones en it_list estan ordenadas, es decir si
// las posiciones en it_list son (p0,p1,...)  entonces el iterator p0
// esta antes del p1, el p1 antes del p2 y asi siguiendo. Tener en cuenta
// que algunos de los iteradores en it_list podrian ser end()

// CONSIGNA: Escribir una funcion bool orditers(list<int> &L,
// list<list::iterator> &it_list); que determina si las posiciones en
// it_list estan ordenadas o no. Se asume que las posiciones en it_list
// son posiciones validas en L. 

// RESTRICCIONES: el algoritmo debe ser O(n)

typedef list<int>::iterator it1_t;
typedef list<it1_t>::iterator it2_t;
bool orditers(list<int> &L, list<it1_t> &it_list) {
  it2_t p = it_list.begin(), q;
  if (p==it_list.end()) return true;
  q = p; q++;
  if (q==it_list.end()) return true;
  it1_t r;
  while (q!=it_list.end()) {
    r = *p;
    while (r!=L.end() && r!=*q) r++;
    if (r!=*q) return false;
    p = q;
    q++;
  }
  return true;
}

int main() {
  list<int> L;
  int N=20;
  for (int j=0; j<N; j++) L.push_back(rand()%N);
  printl(L);
  list<it1_t> it_list;
  vector<it1_t> it_vec;
  it1_t p = L.begin();
  while (p!=L.end()) {
    if (rand()%2) it_vec.push_back(p);
    p++;
  }
#if 1
  random_shuffle(it_vec.begin(),it_vec.end());
#elif 0
  int j1=rand()%N, j2=rand()%N;
  it1_t tmp = it_vec[j1];
  it_vec[j1] = it_vec[j2];
  it_vec[j2] = tmp;
#elif 0
  it_vec.erase(it_vec.begin()+N/2,it_vec.begin()+N);
#endif  
  for (int j=0; j<it_vec.size(); j++) 
    it_list.push_back(it_vec[j]);

  it2_t r = it_list.begin();
  while (r!=it_list.end()) printf("%d ",**r++);
  printf("\n");
  printf("posiciones ordenadas? %d\n",orditers(L,it_list));
  return 0;
}
