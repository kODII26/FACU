//$Id$
/* COMIENZO DE DESCRIPCION

   [Tomado xxx parcial de xxx, 2010-xx-xx]
   Keywords: arbol orientado

   FIN DE DESCRIPCION */

// -----------------------------------------------------------------
#include <cstdio>
#include <iostream>
#include "./util.h"
#include "./tree.h"
#include "./util_tree.h"

using namespace aed;
using namespace std;

// typedef tree<int> tree_t;
// typedef tree<int>::iterator node_t;
typedef list<int> list_t;
typedef list<int>::iterator pos_t;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
node_t 
prepost2tree(tree_t &T, node_t n,
             list_t &preord,pos_t &npre,
             list_t &postord,pos_t &npos) {
  // Inserta el nodo
  n = T.insert(n,*npre);
  
  // Reconstruye los hijos
  node_t c = n.lchild();
  pos_t cpre = npre; cpre++;
  pos_t cpos = npos;
  while (*cpos!=*npre) {
    if (cpos==postord.end()) 
      printf("No se pudo encontrar el nodo %d. "
             "Probablemente las listas de preorden y "
             "postorden no son consistentes.",*npre);
    c = prepost2tree(T,c,preord,cpre,postord,cpos);
    c++;
  }
  cpos++;
  npre = cpre;
  npos = cpos;
  return n;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void prepost2tree(tree_t &T,list<int> &pre,
                  list<int> &post) {
  pos_t 
    ppre = pre.begin(),
    ppost = post.begin();
  prepost2tree(T,T.begin(),pre,ppre,post,ppost);
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main1() {
  list_t pre,post;
  add_to_list(pre,-1,1,2,5,6,3,7,8,4,9,10,-1);
  add_to_list(post,-1,5,6,2,7,8,3,9,10,4,1,-1);
  tree_t T;
  prepost2tree(T,pre,post);
  T.lisp_print();
  printf("\n");
  return 0 ;
} 

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void preorder(tree_t &T,node_t n,
               list_t &L) {
  if (n==T.end()) return;
  L.push_back(*n);
  node_t c = n.lchild();
  while (c!=T.end()) preorder(T,c++,L);
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void postorder(tree_t &T,node_t n,
               list_t &L) {
  if (n==T.end()) return;
  node_t c = n.lchild();
  while (c!=T.end()) postorder(T,c++,L);
  L.push_back(*n);
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int remaptree(tree_t &T,node_t n,set<int> &used) {
  int count=0;
  if (used.find(*n)!=used.end()) {
    int k=1;
    while (used.find(k)!=used.end()) k++;
    *n = k;
    count++;
  }
  used.insert(*n);
  node_t c = n.lchild();
  while (c!=T.end()) count += remaptree(T,c++,used);
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int remaptree(tree_t &T) {
  set<int> used;
  return remaptree(T,T.begin(),used);
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
  for (int j=0; j<20; j++) {
    printf("-----------------\n");
    tree_t T;
    make_random_tree(T,10,2);
    int count = remaptree(T);
    if (count) printf("remapped %d nodes\n",count);
    printf("tree T: ");
    T.lisp_print();
    printf("\n");

    list_t pre,post;
    preorder(T,T.begin(),pre);
    printf("Orden previo: ");
    printl(pre);

    postorder(T,T.begin(),post);
    printf("Orden posterior: ");
    printl(post);
    
    tree_t T2;
    prepost2tree(T2,pre,post);
    printf("Arbol reconstruido: ");
    T2.lisp_print();
    printf("\n");
 
  }
  return 0;
}
