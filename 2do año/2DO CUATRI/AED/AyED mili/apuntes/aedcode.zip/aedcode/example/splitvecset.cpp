// $Id$

/* 
   COMIENZO DE DESCRIPCION 

   __USE_WIKI__
   [Tomado en tercer parcial ].
   keywords: conjunto, correspondencia 
    
   FIN DE DESCRIPCION */

// -----------------------------------------------------------------
#include <cassert>
#include <cstdio>
#include <cmath>
#include <vector>
#include <set>
#include "./util.h"
using namespace std ;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void printset(const set<int> &s,const char *label=NULL) {
  if (label) printf("%s: ",label);
  set<int>::iterator q = s.begin();
  while (q!=s.end()) printf("%d ",*q++);
  printf("\n");
}

void split_vecset(vector< set<int> > &vecset,int x,
                   vector< set<int> > &hasx) {
  hasx.clear();
  vector< set<int> >::iterator q = vecset.begin();
  while (q!=vecset.end()) {
    set<int> &s = *q++;
    if (s.find(x)!=s.end()) {
      hasx.push_back(s);
    }
    // Sin referencias
    // if (q->find(x)!=q->end()) {
    //   hasx.push_back(*q);
    // }
  }
}

int main() {
  int nset = 10, setsize=20;
  vector< set<int> > vecset(nset);
  for (int j=0; j<nset; j++) {
    set<int> &s = vecset[j];
    for (int k=0; k<setsize; k++)
      s.insert(rand()%30);
  }
  
  for (int j=0; j<nset; j++) {
    printf("vecset[%d]: ",j);
    printset(vecset[j]);
  }
  
  vector< set<int> > hasx;
  split_vecset(vecset,2,hasx);

  printf("Aquellos que tienen a 2: \n");
  for (int j=0; j<hasx.size(); j++) {
    printf("vecset[%d]: ",j);
    printset(hasx[j]);
  }
  return 0;
}
