//$Id$
/* COMIENZO DE DESCRIPCION

   __USE_WIKI__
   Escribir una funcion #list2btree(tree<int> &T,list<int> &L);# 
   que dada una lista #L# con el orden previo del AB #T# y el tamano
   de sus subarboles reconstruye #T#. La forma de almacenar el
   arbol en #T# es la siguiente: 
   a) Si #n# es interno (o sea no es una hoja) se almacena 
   #list2tree(n) = (size(n) *n list2tree(hl) list2tree(hr))#
   b) Si el nodo es no dereferenciable (Lambda)
   entonces #list2tree(n) = (0 X)# (donde #X# es cualquier valor, irrelevante)
   c) Si el nodo es una hoja: #list2tree(n) = (1 *n)". 
   Por ejemplo, si #T=(1 (3 (5 (7 . (9 8 4)))) .))# tenemos
   #L=(7 1 6 3 1 5 4 7 0 X 3 9 1 8 1 4 0 X)#. 
   Keywords: arbol binario

   FIN DE DESCRIPCION */

// -----------------------------------------------------------------
#include <cstdio>
#include "./util.h"
#include "./btree.h"
#include "./btreetools.h"

using namespace aed;
using namespace std;

typedef list<int> list_t;
typedef list_t::iterator pos_t;
typedef btree<int> btree_t;
typedef btree_t::iterator node_t;

#define X -1

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int btree2list(btree_t &T,node_t n,list_t &L) {
  if (n==T.end()) {
    L.push_back(0);
    L.push_back(X);
    return 0;
  } 
  node_t 
    hl = n.left(),
    hr = n.right();
  if (hr==T.end() && hl==T.end()) {
    L.push_back(1);
    L.push_back(*n);
    return 1;
  }
  int count = 1;
  pos_t p = L.insert(L.end(),0);
  L.push_back(*n);
  count += btree2list(T,hl,L);
  count += btree2list(T,hr,L);
  *p = count;
  return count;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void btree2list(btree_t &T,list_t &L) {
  btree2list(T,T.begin(),L);
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int list2btree(btree_t &T,node_t n,list_t &L,pos_t &p) {
  int count = *p++;
  int nval = *p++;
  if (count==0) return 0;
  n = T.insert(n,nval);
  if (count==1) return 1;
  int loaded = 
    1 + list2btree(T,n.left(),L,p) + list2btree(T,n.right(),L,p);
  assert(count==loaded);
  return count;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void list2btree(btree_t &T,list_t &L) {
  pos_t p = L.begin();
  list2btree(T,T.begin(),L,p);
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void btree2list_2(btree_t &T,node_t n,list_t &L) {
  if (n==T.end()) return;
  node_t 
    hl = n.left(),
    hr = n.right();
  int son_mask = 0;
  if (hl!=T.end()) son_mask |= 1;
  if (hr!=T.end()) son_mask |= 2;
  L.insert(L.end(),*n);
  L.insert(L.end(),son_mask);
  btree2list_2(T,hl,L);
  btree2list_2(T,hr,L);
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void btree2list_2(btree_t &T,list_t &L) {
  btree2list_2(T,T.begin(),L);
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void list2btree_2(btree_t &T,node_t n,list_t &L,pos_t &p) {
  n = T.insert(n,*p++);
  int son_mask = *p++;
  if (son_mask & 1) list2btree_2(T,n.left(),L,p);
  if (son_mask & 2) list2btree_2(T,n.right(),L,p);
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void list2btree_2(btree_t &T,list_t &L) {
  pos_t p = L.begin();
  if (p!=L.end()) 
    list2btree_2(T,T.begin(),L,p);
}

#define btree2list btree2list_2
#define list2btree list2btree_2

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
  btree_t T,Q;
  list_t L;
  for (int j=0; j<10; j++) {
    T.clear(); Q.clear(); L.clear();
    make_random_btree(T, 10, 1.4);  
    printf("=============\n");
    T.lisp_print();
    printf("\n");

    btree2list(T,L);
    printl(L);

    list2btree(Q,L);
    Q.lisp_print();
    printf("\n");
  }
  
  return 0;
}
