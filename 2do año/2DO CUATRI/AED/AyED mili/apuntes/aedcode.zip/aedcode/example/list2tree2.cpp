//$Id$
// Otra variante de `list2tree'. Guarda el
// tamano del subarbol y el valor del nodo

// -----------------------------------------------------------------
#include <cstdio>
#include <iostream>
#include "./util.h"
#include "./tree.h"
#include "./util_tree.h"

using namespace aed;
using namespace std;

// typedef tree<int> tree_t;
// typedef tree<int>::iterator node_t;
typedef list<int> list_t;
typedef list<int>::iterator pos_t;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
node_t 
list2tree(tree_t &T, node_t n,
          list_t &L,pos_t &p) {
  // Inserta el nodo
  int sz = *p++;
  n = T.insert(n,*p++);
  sz--;
  
  // Reconstruye los hijos
  node_t c = n.lchild();
  while (sz>0) {
    sz -= *p;
    c = list2tree(T,c,L,p);
    c++;
  }
  return n;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void list2tree(tree_t &T,list_t &L) {
  pos_t p = L.begin();
  list2tree(T,T.begin(),L,p);
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void tryl(list_t &L) {
  printl(L);
  tree_t T;
  list2tree(T,L);
  T.lisp_print();
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int tree2list(tree_t &T,node_t n,list_t &L) {
  pos_t p = L.end(),q,r;
  p = L.insert(p,0); 
  q = p; q++;
  q = L.insert(q,*n); q++;
  int sz = 1;
  node_t c = n.lchild();
  while (c!=T.end()) sz += tree2list(T,c++,L);
  *p = sz;
  return sz;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void tree2list(tree_t &T,list_t &L) {
  tree2list(T,T.begin(),L);
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
  for (int j=0; j<20; j++) {
    printf("-----------------\n");
    tree_t T;
    make_random_tree(T,10,2);
    printf("tree T: ");
    T.lisp_print();
    printf("\n");

    list_t L;
    tree2list(T,L);
    printl(L);

    tree_t T2;
    list2tree(T2,L);
    printf("Arbol reconstruido: ");
    T2.lisp_print();
    printf("\n");
 
  }

  
  tree_t T;
  list_t L;

  // Debe dar T = (6 4 8 (5 4 4) 7 9)
  add_to_list(L,-1,6,5,4,0,8,0,5,2,4,0,4,0,7,0,9,0,-1);
  list2tree(T,L);
  T.lisp_print();
  printf("\n");
  return 0;
}
