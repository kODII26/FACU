// $Id$

/* COMIENZO DE DESCRIPCION 

   __USE_WIKI__

   Dado una lista de conjuntos de enteros !+LS+, y un conjunto !+W+
   encontrar la lista !+LSUB+ de aquellos conjuntos $S_j$ de !+LS+
   tales que son subconjuntos de !+W+ ($S_j\subseteq W_j$). Tambien
   debe devolver los conjuntos !+LSUP+ que son supraconjuntos de !+W+,
   [Tomado en el RECUP TPL3 2013-11-21].
   keywords: conjunto

   FIN DE DESCRIPCION */
#include <cstdio>

#include <iostream>
#include <set>
#include <list>
#include <algorithm>
#include "./util.h"

using namespace std ;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
#define STERM -1
#define TERM -2
int velem[]={5,7,11,STERM,0,1,3,STERM,1,2,10,STERM,7,13,22,STERM,TERM};

typedef list< set<int> > ls_t;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void printls(ls_t &ls) {
  ls_t::iterator q = ls.begin();
  int j=0;
  while (q!=ls.end()) {
    set<int> &S= *q++;
    printf("S[%d]= {",j++);
    set<int>::iterator s = S.begin();
    while (s!=S.end()) printf("%d ",*s++);
    printf("}\n");
  }
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void prints(const set<int> &S,const char*label=NULL) {
  if (label) printf("%s={",label);
  printf("{");
  set<int>::iterator s = S.begin();
  while (s!=S.end()) printf("%d ",*s++);
  printf("}\n");
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void subsup(ls_t &LS,set<int> &W,ls_t &LSUB,ls_t &LSUP) {

  LSUB.clear();
  LSUP.clear();

  ls_t::iterator p = LS.begin();
  while (p!=LS.end()) {
    set<int> Sj = *p;
    set<int> aux;
    set_difference(Sj.begin(),Sj.end(),W.begin(),W.end(),
                   inserter(aux,aux.end()));
    if (aux.empty()) LSUB.push_back(Sj);

    aux.clear();
    set_difference(W.begin(),W.end(),Sj.begin(),Sj.end(),
                   inserter(aux,aux.end()));
    if (aux.empty()) LSUP.push_back(Sj);
    p++;
  }
}

//--------------------------------------------------------------------
int main() {
  ls_t S,W;
  int j=0,x;
  while (1) {
    set<int> tmp;
    while (1) {
      x = velem[j++];
      if (x==TERM) break;
      if (x==STERM) {
        S.push_back(tmp);
        break;
      }
      tmp.insert(x);
    }
    if (x==TERM) break;
  }
  printls(S);
  gatherset(S,W);
  printls(W);
  return 0;
}
