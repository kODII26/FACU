#include <vector>
#include <map>
#include <algorithm>
// #include <iostream>
#include <cstdio>

using namespace std;
typedef map<int,int> map_t;

void print_map(map_t &M, const char* label=NULL) {
  if (label) printf("%s\n",label);
  map_t::iterator p = M.begin();
  while (p!=M.end()) {
    printf("M[%d] = %d\n",p->first,p->second);
    p++;
  }
}

void compose(map_t &M1,map_t &M2,map_t &M) {
  M.clear();
  map_t::iterator p=M1.begin();
  while (p!=M1.end()) {
    int key=p->first;
    int val=p->second;
    map_t::iterator q = M2.find(val);
    if (q!=M2.end()) {
      M[key] = q->second;
    }
    p++;
  }
}

bool is_identity(map_t &M) {
  map_t::iterator p = M.begin();
  while (p!=M.end()) {
    if (p->first!=p->second) return false;
    p++; 
  }
  return true;
}

void rand_perm(map_t &M,int N) {
  vector<int> v(N);
  for (int j=0; j<N; j++) v[j] = j;
  random_shuffle(v.begin(),v.end());
  for (int j=0; j<N; j++) M[j] = v[j];
}

