/* COMIENZO DE DESCRIPCION

   __USE_WIKI__
   Dados dos grafos $G_1=(V_1,E_1)$ y $G_2=(V_2,E_2)$ determinar si $G_2$
   es un subgrafo que se obtiene dejando un cierto conjunto de
   vertices $V_2\subseteq V_1$ y \textbf{todas} las aristas de $E_1$ que
   conectan nodos de $V_2$. \\
   \textbf{Consigna:} Escribir una funcion 
   %
   !+bool issubgraph(graph_t &G1,graph_t &G2);+ 
   %
   que realiza la tarea indicada. \\
   Si lo aplicamos a los grafos de abajo entonces debemos tener 
   !+issubgraph(G1,G2) -> T+ y !+issubgraph(G1,G3) -> F+ ya que la arista
   $(2,7)$ esta en !+G1+ pero no en !+G3+. 

   [Tomado en el 3er parcial de 2012-11-22].  
   keywords: set, map

  FIN DE DESCRIPCION */
// -------------------------------------------------------------------

#include <cstdio>
#include <cassert>
#include <cmath>

#include <map>
#include <set>

#include "./util.h"

using namespace std;

typedef map<int, set<int> > graph_t;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
bool issubgraph(const graph_t &G1,const graph_t &G2) {
  // Chequea que todos los vertices de G2 sean vertices de g1
  graph_t::const_iterator q2 = G2.begin();
  set<int> V2;
  while (q2!=G2.end()) {
    if (G1.find(q2->first)==G2.end()) 
      return false;
    V2.insert(q2->first);
    q2++;
  }

  graph_t::const_iterator q1 = G1.begin();
  // Recorre los vertices de G1
  while (q1!=G1.end()) {
    // Se fija si el vertice tambien esta en V2.
    // Si no esta no hay que hacer nada, ya que
    // todas las aristas NO tienen que estar en G2. 
    int v = q1->first;
    graph_t::const_iterator q2 = G2.find(v);
    if (q2!=G2.end()) {
      // Busca los vecinos de `v' en G1 y en G2
      const set<int> 
        &ngbrs1 = q1->second,
        &ngbrs2 = q2->second;
      // Los vecinos en G2 deben ser exactamente los vecinos
      // en G1 interseccion V2
      set<int> tmp;
      set_intersection(ngbrs1.begin(),ngbrs1.end(),V2.begin(),V2.end(),
                       inserter(tmp,tmp.begin()));
      if (tmp!=ngbrs2) return false;
    }
    q1++;
  }
  return true;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void read_graph(graph_t &G, const int *g) {
  const int *p = g;
  while (*p>=0) {
    int 
      v1 = *p++,
      v2 = *p++;
    G[v1].insert(v2);
    G[v2].insert(v1);
  }
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void print_graph(const graph_t &G) {
  graph_t::const_iterator q = G.begin();
  while (q!=G.end()) {
    printf("%d -> {",q->first);
    const set<int> &ngbrs = q->second;
    set<int>::const_iterator r = ngbrs.begin();
    while (r!=ngbrs.end()) 
      printf("%d ",*r++);
    printf("}\n");
    q++;
  }
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
  graph_t G1,G2,G3;

  int g1[] = {0,4, 0,2, 2,1, 1,7, 2,7, 7,6, 6,2, 2,3, 3,6, 5,6, 3,5, 4,5, -1};
  read_graph(G1,g1);
  printf("G1: -------- \n");
  print_graph(G1);
  
  int g2[] = {2,1, 1,7, 2,7, 7,6, 6,2, 2,3, 3,6, -1};
  read_graph(G2,g2);
  printf("G2: -------- \n");
  print_graph(G2);
  
  int g3[] = {2,1, 1,7, 7,6, 6,2, 2,3, 3,6, -1};
  read_graph(G3,g3);
  printf("G3: -------- \n");
  print_graph(G3);

  printf("issubgraph(G1,G2): %d\n",issubgraph(G1,G2));
  printf("issubgraph(G1,G3): %d\n",issubgraph(G1,G3));
  
  return 0;
}
