menu(['Bombones de jamon', 'Locro', 'Dulce de batata']).
menu(['Bombones de jamon', 'Locro', 'Alfajor norte�o']).
menu(['Tarta de atun', 'Atados de repollo', 'Dulce de batata']).
menu(['Tarta de atun', 'Pollo romano con hierbas y vino', 'Flan']).
menu(['Volovanes de atun', 'Matambre con espinacas y parmesano', 'Torta moka']).
menu(['Bu�uelos de bacalao', 'Pollo romano con hierbas y vino', 'Alfajor norte�o']).